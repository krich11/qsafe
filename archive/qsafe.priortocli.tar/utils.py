#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Utilities Module
Version: 1.0.0
Authors: Ken Rich
Date: March 24, 2025
Description:
This script performs utilitarian tasks related to this project.
Usage:
To be determined based on the subroutines and functionality added.
"""

import secrets
import base64
import datetime
import logging
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization, padding
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.serialization import pkcs12, BestAvailableEncryption
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def generate_key():
    """
    Generate a new RSA private key.
    :return: RSA private key
    """
    return rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )

def generate_self_signed_ca():
    """
    Generate a self-signed CA certificate and key.
    :return: Tuple containing the CA key and CA certificate
    """
    ca_key = generate_key()
    ca_subject = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, "Self-Signed CA")
    ])
    ca_cert = x509.CertificateBuilder().subject_name(ca_subject).issuer_name(ca_subject).public_key(
        ca_key.public_key()).serial_number(1).not_valid_before(
        datetime.datetime.utcnow()).not_valid_after(
        datetime.datetime.utcnow() + datetime.timedelta(days=3650)).sign(ca_key, hashes.SHA256(), default_backend())
    return ca_key, ca_cert

def load_ca_from_file(filename, password):
    """
    Load CA certificate and key from a PKCS12 file.
    :param filename: The filename of the PKCS12 file
    :param password: The password for the PKCS12 file
    :return: Tuple containing the CA certificate and CA key
    """
    with open(filename, "rb") as f:
        p12 = serialization.load_pkcs12(f.read(), password.encode())
        return p12.certificates, p12.key

def generate_idevid(serial_number, mac_address, filename=None, password=None):
    """
    Generate an IDevID certificate and related keys.
    :param serial_number: Serial number of the device
    :param mac_address: MAC address of the device
    :param filename: Optional filename to load CA certificate and key
    :param password: Optional password for the PKCS12 file
    :return: Tuple containing CA key, CA certificate, device key, CSR, and device certificate
    """
    try:
        key = generate_key()
        subject = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, f"{serial_number}::{mac_address}")
        ])
        san = x509.SubjectAlternativeName([
            x509.DNSName(f"{serial_number}::{mac_address}")
        ])
        csr = x509.CertificateSigningRequestBuilder().subject_name(
            subject).add_extension(san, critical=False).sign(
            key, hashes.SHA256(), default_backend())

        if filename is None:
            ca_key, ca_cert = generate_self_signed_ca()
        else:
            ca_cert, ca_key = load_ca_from_file(filename, password)

        idevid_cert = x509.CertificateBuilder().subject_name(
            subject).issuer_name(ca_cert.subject).public_key(
            key.public_key()).serial_number(
            int.from_bytes(serial_number.encode(), 'big')).not_valid_before(
            datetime.datetime.utcnow()).not_valid_after(
            datetime.datetime.utcnow() + datetime.timedelta(days=365)).add_extension(
            san, critical=False).sign(ca_key, hashes.SHA256(), default_backend())

        return ca_key, ca_cert, key, csr, idevid_cert
    except Exception as e:
        logging.error("An error occurred during IDevID generation: %s", str(e))
        raise

def save_cert(key, cert, filename, password=None):
    """
    Save certificate and key to files.
    :param key: Private key to save
    :param cert: Certificate to save
    :param filename: Base filename to save files as
    :param password: Optional password for P12 encryption
    """
    try:
        if password:
            p12 = pkcs12.serialize_key_and_certificates(
                name=b"Certificate", key=key, cert=cert, cas=None,
                encryption_algorithm=BestAvailableEncryption(password.encode())
            )
            with open(filename + ".p12", "wb") as f:
                f.write(p12)
        else:
            with open(f"{filename}_key.pem", "wb") as f:
                f.write(key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.TraditionalOpenSSL,
                    encryption_algorithm=serialization.NoEncryption()
                ))
            with open(f"{filename}_cert.pem", "wb") as f:
                f.write(cert.public_bytes(
                    serialization.Encoding.PEM
                ))
    except Exception as e:
        logging.error("An error occurred while saving the certificate: %s", str(e))
        raise

def encrypt_data(data, key):
    """
    Encrypt data using AES256.
    :paramData to encrypt
    :param key: Encryption key
    :return: Encrypted data as base64-encoded string
    """
    try:
        iv = secrets.token_bytes(16)
        cipher = Cipher(
            algorithms.AES(key),
            modes.CBC(iv),
            backend=default_backend()
        )
        encryptor = cipher.encryptor()

        padder = padding.PKCS7(algorithms.AES.block_size).padder()
        padded_data = padder.update(data) + padder.finalize()

        encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
        return base64.b64encode(iv + encrypted_data).decode('utf-8')
    except Exception as e:
        logging.error("Error encrypting%s", str(e))
        raise

def decrypt_data(encrypted_data_b64, key):
    """
    Decrypt data using AES256.
    :param encrypted_data_b64: Encrypted data as base64-encoded string
    :param key: Decryption key
    :return: Decrypted data
    """
    try:
        encrypted_data = base64.b64decode(encrypted_data_b64)
        iv = encrypted_data[:16]
        encrypted_data = encrypted_data[16:]

        cipher = Cipher(
            algorithms.AES(key),
            modes.CBC(iv),
            backend=default_backend()
        )
        decryptor = cipher.decryptor()

        decrypted_padded_data = decryptor.update(encrypted_data) + decryptor.finalize()
        unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
        return unpadder.update(decrypted_padded_data) + unpadder.finalize()
    except Exception as e:
        logging.error("Error decrypting%s", str(e))
        raise

