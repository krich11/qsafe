import json
import os
import secrets
import logging
import base64
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
from cryptography import x509
from utils import encrypt_data, decrypt_data

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class Device:
    def __init__(self):
        self.idevid_private_key = None
        self.idevid_certificate = None
        self.private_key = None
        self.certificate = None
        self.serial_number = None
        self.mac_address = None
        self.entropy = secrets.token_bytes(4096)  # Generate 4096 bytes of random data
        self.storage_key = secrets.token_bytes(32)  # Generate 256-bit storage key

    def store_private_key(self, private_key):
        """
        Store the private key after encrypting it.
        
        :param private_key: The private key to store
        """
        try:
            private_key_der = private_key.private_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            )
            self.private_key = encrypt_data(private_key_der, self.storage_key)
        except Exception as e:
            logging.error("Error storing private key: %s", str(e))
            raise

    def store_certificate(self, certificate):
        """
        Store the certificate.
        
        :param certificate: The certificate to store
        """
        self.certificate = certificate

    def idevid_store_private_key(self, private_key):
        """
        Store the IDevID private key after encrypting it.
        
        :param private_key: The IDevID private key to store
        """
        try:
            private_key_der = private_key.private_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            )
            self.idevid_private_key = encrypt_data(private_key_der, self.storage_key)
        except Exception as e:
            logging.error("Error storing IDevID private key: %s", str(e))
            raise

    def idevid_store_certificate(self, certificate):
        """
        Store the IDevID certificate.
        
        :param certificate: The IDevID certificate to store
        """
        self.idevid_certificate = certificate

    def idevid_get_private_key(self, format='DER'):
        """
        Retrieve the decrypted IDevID private key.
        
        :param format: The format to return the private key in ('DER' or 'PEM')
        :return: The decrypted IDevID private key in the specified format
        """
        try:
            decrypted_idevid_private_key_der = decrypt_data(self.idevid_private_key, self.storage_key)
            idevid_private_key = serialization.load_der_private_key(
                decrypted_idevid_private_key_der,
                password=None,
                backend=default_backend()
            )

            if format == 'PEM':
                return idevid_private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.TraditionalOpenSSL,
                    encryption_algorithm=serialization.NoEncryption()
                )

            return decrypted_idevid_private_key_der
        except Exception as e:
            logging.error("Error retrieving IDevID private key: %s", str(e))
            raise

    def idevid_get_certificate(self, format=None):
        """
        Retrieve the IDevID certificate.
        
        :param format: The format to return the certificate in ('DER' or 'PEM')
        :return: The IDevID certificate in the specified format
        """
        try:
            if isinstance(self.idevid_certificate, bytes):
                self.idevid_certificate = x509.load_der_x509_certificate(
                    self.idevid_certificate,
                    backend=default_backend()
                )

            if format == 'PEM':
                return self.idevid_certificate.public_bytes(serialization.Encoding.PEM)
            elif format == 'DER':
                return self.idevid_certificate.public_bytes(serialization.Encoding.DER)
            return self.idevid_certificate
        except Exception as e:
            logging.error("Error retrieving IDevID certificate: %s", str(e))
            raise

    def set_serial_number(self, serial_number):
        """
        Set the serial number of the device.
        
        :param serial_number: The serial number to set
        """
        self.serial_number = serial_number

    def set_mac_address(self, mac_address):
        """
        Set the MAC address of the device.
        
        :param mac_address: The MAC address to set
        """
        self.mac_address = mac_address

    def get_private_key(self, format='DER'):
        """
        Retrieve the decrypted private key.
        
        :param format: The format to return the private key in ('DER' or 'PEM')
        :return: The decrypted private key in the specified format
        """
        try:
            decrypted_private_key_der = decrypt_data(self.private_key, self.storage_key)
            private_key = serialization.load_der_private_key(
                decrypted_private_key_der,
                password=None,
                backend=default_backend()
            )

            if format == 'PEM':
                return private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.TraditionalOpenSSL,
                    encryption_algorithm=serialization.NoEncryption()
                )

            return decrypted_private_key_der
        except Exception as e:
            logging.error("Error retrieving private key: %s", str(e))
            raise

    def get_certificate(self, format=None):
        """
        Retrieve the certificate.
        
        :param format: The format to return the certificate in ('DER' or 'PEM')
        :return: The certificate in the specified format
        """
        try:
            if isinstance(self.certificate, bytes):
                self.certificate = x509.load_der_x509_certificate(
                    self.certificate,
                    backend=default_backend()
                )

            if format == 'PEM':
                return self.certificate.public_bytes(serialization.Encoding.PEM)
            elif format == 'DER':
                return self.certificate.public_bytes(serialization.Encoding.DER)
            return self.certificate
        except Exception as e:
            logging.error("Error retrieving certificate: %s", str(e))
            raise

    def get_serial_number(self):
        """
        Retrieve the serial number of the device.
        
        :return: The serial number of the device
        """
        return self.serial_number

    def get_mac_address(self):
        """
        Retrieve the MAC address of the device.
        
        :return: The MAC address of the device
        """
        return self.mac_address

    def save_to_file(self, filename):
        """
        Save the device properties to a JSON file in a pretty format.

        :param filename: The name of the file to save the properties to
        """
        try:
            # Check if the private key is not None before decrypting it
            if self.private_key is not None:
                decrypted_private_key_der = decrypt_data(self.private_key, self.storage_key)
                decrypted_private_key = serialization.load_der_private_key(
                    decrypted_private_key_der,
                    password=None,
                    backend=default_backend()
                )
                private_key_pem = decrypted_private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.TraditionalOpenSSL,
                    encryption_algorithm=serialization.NoEncryption()
                ).decode('utf-8')
            else:
                private_key_pem = None

            # Check if the idevid private key is not None before decrypting it
            if self.idevid_private_key is not None:
                decrypted_idevid_private_key_der = decrypt_data(self.idevid_private_key, self.storage_key)
                decrypted_idevid_private_key = serialization.load_der_private_key(
                    decrypted_idevid_private_key_der,
                    password=None,
                    backend=default_backend()
                )
                idevid_private_key_pem = decrypted_idevid_private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.TraditionalOpenSSL,
                    encryption_algorithm=serialization.NoEncryption()
                ).decode('utf-8')
            else:
                idevid_private_key_pem = None

            data = {
                "private_key": private_key_pem,
                "certificate": self.certificate.public_bytes(
                    serialization.Encoding.PEM
                ).decode('utf-8') if self.certificate else None,
                "idevid_private_key": idevid_private_key_pem,
                "idevid_certificate": self.idevid_certificate.public_bytes(
                    serialization.Encoding.PEM
                ).decode('utf-8') if self.idevid_certificate else None,
                "serial_number": self.serial_number,
                "mac_address": self.mac_address
            }

            with open(filename, 'w') as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            logging.error("Error saving to file: %s", str(e))
            raise

    def load_from_file(self, filename):
        """
        Load the device properties from a JSON file.

        :param filename: The name of the file to load the properties from
        """
        try:
            if not os.path.exists(filename):
                raise FileNotFoundError(f"{filename} does not exist")

            with open(filename, 'r') as f:
                data = json.load(f)

            if data["private_key"]:
                private_key_pem = data["private_key"].encode('utf-8')
                private_key_der = serialization.load_pem_private_key(
                    private_key_pem,
                    password=None,
                    backend=default_backend()
                ).private_bytes(
                    encoding=serialization.Encoding.DER,
                    format=serialization.PrivateFormat.TraditionalOpenSSL,
                    encryption_algorithm=serialization.NoEncryption()
                )
                self.private_key = encrypt_data(private_key_der, self.storage_key)

            if data["certificate"]:
                certificate_pem = data["certificate"].encode('utf-8')
                self.certificate = x509.load_pem_x509_certificate(
                    certificate_pem,
                    backend=default_backend()
                )

            if data["idevid_private_key"]:
                idevid_private_key_pem = data["idevid_private_key"].encode('utf-8')
                idevid_private_key_der = serialization.load_pem_private_key(
                    idevid_private_key_pem,
                    password=None,
                    backend=default_backend()
                ).private_bytes(
                    encoding=serialization.Encoding.DER,
                    format=serialization.PrivateFormat.TraditionalOpenSSL,
                    encryption_algorithm=serialization.NoEncryption()
                )
                self.idevid_private_key = encrypt_data(idevid_private_key_der, self.storage_key)

            if data["idevid_certificate"]:
                idevid_certificate_pem = data["idevid_certificate"].encode('utf-8')
                self.idevid_certificate = x509.load_pem_x509_certificate(
                    idevid_certificate_pem,
                    backend=default_backend()
                )

            self.serial_number = data["serial_number"]
            self.mac_address = data["mac_address"]
        except Exception as e:
            logging.error("Error loading from file: %s", str(e))
            raise

    def dump_properties(self):
        """
        Print the device properties for debugging purposes.
        """
        properties = {
            "idevid_private_key": str(self.idevid_private_key),
            "idevid_certificate": str(self.idevid_certificate),
            "private_key": str(self.private_key),
            "certificate": str(self.certificate),
            "serial_number": str(self.serial_number),
            "mac_address": str(self.mac_address),
            "entropy": str(base64.b64encode(self.entropy).decode('utf-8')),
            "storage_key": str(base64.b64encode(self.storage_key).decode('utf-8'))
        }

        for key, value in properties.items():
            print(f"{key}: {value}")

# Example usage:
# device = Device()
# device.store_private_key(private_key)
# device.store_certificate(certificate)
# device.set_serial_number("123456")
# device.set_mac_address("00:11:22:33:44:55")
# device.save_to_file("device_data.json")
# device.load_from_file("device_data.json")
# device.dump_properties()

